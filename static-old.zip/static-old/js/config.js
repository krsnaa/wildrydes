window._config = {
  cognito: {
    userPoolId: "us-east-1_VeBnIr0ZK", // e.g. us-east-2_uXboG5pAb
    userPoolClientId: "6n9t3ho1m5u4edbi5fk66qlteo", // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
    region: "us-east-1" // e.g. us-east-2
  },
  api: {
    invokeUrl: "https://fxjubyw011.execute-api.us-east-1.amazonaws.com/prod" // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod,
  }
};
